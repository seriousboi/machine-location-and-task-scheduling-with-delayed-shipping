Jobs= 10 // line 1 gives |J|
Locations = 4 // line 2 gives |K|
Machines = 2 // line 3 gives m
Tardiness penalty = // line 4 gives \lambda_3 (it is assumed that \lambda_1=\lambda_2=1)
Processing = [26, 95, 42, 75, 33, 39, 3, 76, 63, 91]  // line 5 gives p_j for every job j\in J
Job_coordinate = [[9, 13],[49, 90],[44, 74],[47, 78],[81, 82],[84, 61],[3, 36],[28, 10],[6, 0],[37, 99]]  // line 6 gives the coordinates (x_j,y_j) of the original location of each job j\in J
Location_coordinate = [[38, 2],[6, 80],[68, 99],[41, 26]]  // line 7 gives the coordinates (x_k,y_k) of each site k\in K
Fixedcost = [50, 30, 70, 40]  // line 8 gives the cost c_k of installing a machine in site k\in K
Duedate = [225, 228, 207, 201, 227, 212, 206, 239, 216, 222]  // line 9 gives the due date for every job j\in J
// The distance $D_jk$ is computed as the Euclidean distance between the coordinates of site k and the coordinates of job j, rounded down to the nearest integer
// For all the instances, it is assumed that for every pair (j,k) of site/job the speed is u_{jk}=1 and the cost per unit of distance is f_{jk}=3
